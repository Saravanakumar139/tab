package com.example.saravana.tab.Fragments


import android.os.Bundle
import android.os.StrictMode
import android.support.v4.app.Fragment
import android.view.*
import com.example.saravana.tab.R


class Tab2Fragment : Fragment() {

    var NewBillKey=""
    var frm=""
    lateinit var rootView:View
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for activity!! fragment
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        rootView= inflater.inflate(R.layout.tab2, container, false)


        return rootView
    }


    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        //inflater!!.inflate(R.menu.save_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return super.onOptionsItemSelected(item)
    }
}
