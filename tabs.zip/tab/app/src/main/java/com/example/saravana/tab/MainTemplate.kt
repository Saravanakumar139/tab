package com.example.saravana.tab

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity

import android.util.Log
import android.view.*
import android.widget.Toast
import com.example.saravana.tab.Fragments.Tab2Fragment
import com.example.saravana.tab.Fragments.Tab1Fragment
import com.example.saravana.tab.Fragments.Tab3Fragment


class MainTemplate : AppCompatActivity() {
    
    public var tabactivity: Activity? = null
    //This is our tablayout
    private var tabLayout: TabLayout? = null

    //This is our viewPager
    private var viewPager: ViewPager? = null

    internal var adapter: ViewPagerAdapter? = null

    //Fragments

    internal var tab2Fragment: Tab2Fragment? = null
    internal var tab1Fragment: Tab1Fragment? = null
    internal var tab3Fragment: Tab3Fragment? = null

    private val mContext: Context? = null
    private val mbPermission = false
    private val mnCount = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Initializing viewPager
        viewPager = findViewById(R.id.viewpager) as ViewPager
        viewPager!!.offscreenPageLimit = 3
//Initializing the tablayout
        tabLayout = findViewById<TabLayout>(R.id.tablayout)
        val pre=SessionManagement(this@MainTemplate).userDetails[SessionManagement.permission]

        println("tabLayout!!.selectedTabPosition : "+tabLayout!!.selectedTabPosition)
        println("viewPager!!.currentItem : "+viewPager!!.currentItem)
        if (pre==""){
            //add fisrt time permission
            //and then update the session
            if (viewPager!!.currentItem==0) {
                SessionManagement(this@MainTemplate).setPermission("first")
                Toast.makeText(this@MainTemplate,"First time permission",Toast.LENGTH_LONG).show()
            }
        }


        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewPager!!.setCurrentItem(tab.position, false)
                println("position : "+tab.position)
                if (pre==""){
                    if (tab.position==0||tab.position==2) {
                        //add fisrt time permission
                        //and then update the session
                        SessionManagement(this@MainTemplate).setPermission("first")
                        Toast.makeText(this@MainTemplate,"First time permission",Toast.LENGTH_LONG).show()
                    }
                }else if (pre=="first"){
                    if (tab.position==1) {
                        //here you add second time permission
                        //and then update the session
                        SessionManagement(this@MainTemplate).setPermission("second")
                        Toast.makeText(this@MainTemplate,"Second time permission",Toast.LENGTH_LONG).show()
                    }
                }
                //and so on.....
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {

            }

            override fun onTabReselected(tab: TabLayout.Tab) {

            }
        })

        viewPager!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {

                tabLayout!!.getTabAt(position)!!.select()
                println("position : "+position)
                if (pre==""){
                    if (position==0||position==2) {
                        //add fisrt time permission
                        //and then update the session
                        SessionManagement(this@MainTemplate).setPermission("first")
                        Toast.makeText(this@MainTemplate,"First time permission",Toast.LENGTH_LONG).show()
                    }
                }else if (pre=="first"){
                    if (position==1) {
                        //here you add second time permission
                        //and then update the session
                        SessionManagement(this@MainTemplate).setPermission("second")
                        Toast.makeText(this@MainTemplate,"Second time permission",Toast.LENGTH_LONG).show()
                    }
                }
                //and so on.....

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        setupViewPager(viewPager!!)

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        //val popup = PopupMenu(this@MainTemplate, mr_option)
        // Associate searchable configuration with the SearchView
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return false
    }


    private fun setupViewPager(viewPager: ViewPager) {
        adapter = ViewPagerAdapter(supportFragmentManager)
        tab1Fragment = Tab1Fragment()
        tab3Fragment = Tab3Fragment()
        tab2Fragment = Tab2Fragment()

        adapter!!.addFragment(tab1Fragment!!, "tab1")
        adapter!!.addFragment(tab2Fragment!!, "tab2")
        adapter!!.addFragment(tab3Fragment!!, "tab3")
        viewPager.adapter = adapter

    }

    override fun onBackPressed() {
        finish()
    }

    override fun onStart() {
        super.onStart()
        Log.d("lifecycle", "onStart invoked")
    }

    override fun onResume() {
        super.onResume()
        Log.d("lifecycle", "onResume invoked")
    }

    override fun onPause() {
        super.onPause()
        Log.d("lifecycle", "onPause invoked")
    }

    override fun onStop() {
        super.onStop()
        Log.d("lifecycle", "onStop invoked")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("lifecycle", "onRestart invoked")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("lifecycle", "onDestroy invoked")
    }
}
