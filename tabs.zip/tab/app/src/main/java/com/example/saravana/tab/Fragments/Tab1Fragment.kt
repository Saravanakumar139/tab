package com.example.saravana.tab.Fragments


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.*
import com.example.saravana.tab.R


/**
 * A simple [Fragment] subclass.
 */
class Tab1Fragment : Fragment() {

    lateinit var rootView:View
    var NewBillKey=""
    var frm=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View?{

        rootView=inflater.inflate(R.layout.tab1, container, false)
        //NewBillKey= SessionManagement(activity!!).userDetails[SessionManagement.NewBillKey]!!



        return rootView
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        //inflater!!.inflate(R.menu.menu_calls_fragment, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }
}
