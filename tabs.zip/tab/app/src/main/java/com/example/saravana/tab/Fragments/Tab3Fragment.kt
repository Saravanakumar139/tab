package com.example.saravana.tab.Fragments



import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.*
import com.example.saravana.tab.R


/**
 * A simple [Fragment] subclass.
 */
class Tab3Fragment : Fragment() {


    lateinit var rootView:View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.tab3, container, false)

        return rootView
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        super.onCreateOptionsMenu(menu, inflater)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection

        return false
    }
}
